import urllib.request, json
import pprint

if __name__ == "__main__":

    with urllib.request.urlopen("https://jsonplaceholder.typicode.com/todos") as url:
        data = json.loads(url.read().decode())
        pprint.pprint(data)


