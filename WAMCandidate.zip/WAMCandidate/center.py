from sympy import Polygon


def getcenter(pts):

    poly = Polygon(*pts)
    return (poly.centroid)


if __name__ == "__main__":

    # examples
    points = [(-1, -1), (1,-1), (1, 1), (-1, 1)] # (0, 0)
    # points = [(0, 1), (1,0), (1, 1)] # (0.66, 0.66)
    # points = [(2, 3), (4, 4), (1, 1), (16, 2), (5, 2), (1, 2)] # (7.42, 1.36)

    if len(points) > 2 :
        print(getcenter(points))

