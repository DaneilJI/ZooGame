﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooGame.Game
{
    public interface IAnimal
    {
        string Name { get; set; }
        int HungerLevel { get; set; }
        bool Hungry { get; set; }
        void feed(int feedamount);
        void clean();
        string cry();
    }
}
