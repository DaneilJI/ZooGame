﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooGame.Game
{
    public class Cow : IAnimal
    {
        public string Name { get; set; }
        public int HungerLevel { get; set; } = 100;
        public bool Hungry { get; set; } = true;
        public bool Clean { get; set; }

        #region interface-methods
        public void feed(int feedamount)
        {
            if (feedamount <= 0) throw new ArgumentException("Must have positive feed amount.");

            if (this.HungerLevel > 0)
            {
                this.HungerLevel = Math.Max(0, this.HungerLevel -= feedamount);
                this.Hungry = false;
            }

        }
        public void clean()
        {
            if (this.HungerLevel == 0)
            {
                this.Clean = true;
            }
            else
            {
                this.Clean = false;
            }
        }
        public string cry()
        {
            return "Moo";
        }

        public string pet()
        {
            return this.Name + " is happy!";
        }
        #endregion interface-methods
    }
}
