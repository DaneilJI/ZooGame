﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooGame.Game
{
    public class Tiger : IAnimal
    {
        public string Name { get; set; }
        public int HungerLevel { get; set; } = 100;
        public bool Hungry { get; set; } = true;
        public bool Clean { get; set; }

        #region interface-methods
        public void feed(int feedamount)
        {
            if (feedamount <= 0) throw new ArgumentException("Must have positive feed amount.");

            if (this.HungerLevel > 0)
            {
                this.HungerLevel = Math.Max(0, this.HungerLevel -=feedamount);
                this.Hungry = false;
            }
            Console.WriteLine(this.Name + " has a hungrylevel of: " + this.HungerLevel);
        }
        public void clean()
        {
            if (this.HungerLevel == 0) {
                this.Clean = true;
                Console.WriteLine(this.Name + " needs to be cleaned");
            }
            else
            {
                this.Clean = false;
                Console.WriteLine(this.Name + "  doesn't need to be cleaned");
            }
        }
        public string cry()
        {
            return "Roar";
        }
        #endregion interface-methods
    }
}
