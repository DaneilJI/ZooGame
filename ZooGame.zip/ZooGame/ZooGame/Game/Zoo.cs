﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooGame.Game
{
    public delegate void AnimalChangeHandler(object sender, AnimalChangeEventArgs eventArgs);

    public class Zoo
    {
        private IDictionary<string, IAnimal> _animals;
        
        public Zoo ()
        {
            _animals = new Dictionary<string, IAnimal>();
        }

        public event AnimalChangeHandler AnimalChange;

        #region zooUpkeep
        public void AddAnimal(IAnimal animal)
        {
            if (_animals.ContainsKey(animal.Name))
            {
                fireChange(EventType.Fail, animal.Name);
            }
            else
            {
                _animals.Add(animal.Name, animal);
                fireChange(EventType.Add, animal.Name);
            }
        }

        public void RemoveAnimal(IAnimal animal)
        {
            if (_animals.ContainsKey(animal.Name))
            {
                _animals.Remove(animal.Name);
                fireChange(EventType.Remove, animal.Name);
            }
            else
            {
                fireChange(EventType.Fail, animal.Name);
            }
        }

        public void FeedAnimal(IAnimal animal, int feedamount)
        {
            if (_animals.ContainsKey(animal.Name))
            {
                _animals[animal.Name].feed(feedamount);
                fireChange(EventType.Update, animal.Name);
            }
            else
            {
                fireChange(EventType.Fail, animal.Name);
            }
        }

        private void fireChange(EventType type, string animalname)
        {
            var handler = AnimalChange;
            if (handler != null)
                handler(this, new AnimalChangeEventArgs(type, animalname));
        }
        #endregion
    }

    public enum EventType
    {
        Add,
        Remove,
        Update,
        Fail
    }

    public class AnimalChangeEventArgs : EventArgs
    {
        public EventType Type { get; private set; }
        public string AnimalName { get; private set; }

        public AnimalChangeEventArgs(EventType type, string animalname)
        {
            Type = type;
            AnimalName = animalname;
        }
    }

    public static class ZooExtenions
    {
        public static void AddAnimal(this Zoo zoo, IAnimal animal)
        {
            zoo.AddAnimal(animal);
        }
        public static void RemoveAnimal(this Zoo zoo, IAnimal animal)
        {
            zoo.RemoveAnimal(animal);
        }
        public static void FeedAnimal(this Zoo zoo, IAnimal animal)
        {
            zoo.FeedAnimal(animal);
        }
    }
}


