using NUnit.Framework;
using System;

namespace ZooGame.Game
{
    [TestFixture]
    public class ZooTests
    {
        protected Zoo zoo;
        protected IAnimal hobbes;
        protected IAnimal annabelle;
        protected IAnimal dumbo;

        [SetUp]
        public void Setup()
        {
            hobbes = new Tiger 
            { 
                Name = "Hobbes",
            };
            annabelle = new Cow
            {
                Name = "Annabelle",
            };
            dumbo = new Elephant
            {
                Name = "Dumbo",
            };
            zoo = new Zoo();
            zoo.AddAnimal(annabelle);
            zoo.AddAnimal(dumbo);
        }

        [Test]
        public void TestAddAnimal()
        {
            bool changed = false;
            AnimalChangeHandler tch = (sender, args) =>
            {
                if (args.Type == EventType.Add)
                    changed = true;
            };
            zoo.AnimalChange += tch;
            zoo.AddAnimal(hobbes);
            Assert.IsTrue(changed);
            zoo.AnimalChange -= tch;
        }

        [Test]
        public void TestRemoveAnimal()
        {
            bool changed = false;
            AnimalChangeHandler tch = (sender, args) =>
            {
                if (args.Type == EventType.Remove)
                    changed = true;
            };
            zoo.AnimalChange += tch;
            zoo.RemoveAnimal(annabelle);
            Assert.IsTrue(changed);
            zoo.AnimalChange -= tch;
        }

        [Test]
        public void TestFeedAnimal()
        {
            bool changed = false;
            AnimalChangeHandler tch = (sender, args) =>
            {
                if (args.Type == EventType.Update)
                    changed = true;
            };
            zoo.AnimalChange += tch;
            zoo.FeedAnimal(dumbo, 25);
            Assert.IsTrue(changed);
            zoo.AnimalChange -= tch;
        }
    }
}